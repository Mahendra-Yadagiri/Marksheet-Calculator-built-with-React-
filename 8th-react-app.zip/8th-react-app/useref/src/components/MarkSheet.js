import React, { useRef } from 'react'

function MarkSheet() {
    let firstNameInputRef=useRef();
    let lastNameInputRef=useRef();
    let engInputRef=useRef();
    let telInputRef=useRef();
    let hinInputRef=useRef();
    let matInputRef=useRef();
    let sciInputRef=useRef();
    let socInputRef=useRef();
    let resultLabelRef=useRef();

    let engSpanRef=useRef();
    let telSpanRef=useRef();
    let hinSpanRef=useRef();
    let matSpanRef=useRef();
    let sciSpanRef=useRef();
    let socSpanRef=useRef();

    
    
    

  return (
    <div>
        
     <form>
        <h2>Mark Sheet</h2>
        <div>
            <label>First Name:</label>
            <input ref={firstNameInputRef}
            onFocus={()=>{
                firstNameInputRef.current.style.backgroundColor="aquamarine"
                console.log(`1stName-onFocus`);
            }}
            onChange={()=>{
                firstNameInputRef.current.style.backgroundColor="yellowgreen"
                console.log(`1stName-onChange`);
            }}
            onBlur={()=>{
                firstNameInputRef.current.style.backgroundColor=""
                console.log(`1stName-onBlur`);
            }}>

            </input>
            <span></span>
        </div>
        <div>
            <label>Last Name:</label>
            <input ref={lastNameInputRef}
            onFocus={()=>{
                lastNameInputRef.current.style.backgroundColor="aquamarine"
                console.log(`2ndName-Focus`);
            }}
            onChange={()=>{
                lastNameInputRef.current.style.backgroundColor="yellowgreen"
                console.log(`2ndName-onChange`);
            }}
            onBlur={()=>{
                lastNameInputRef.current.style.backgroundColor=""
                console.log(`2ndName-onBlur`);
            }}></input>
            <span></span>
            
        </div>
        <div>
            <label>English:</label>
            <input ref={engInputRef}
            onFocus={()=>{
                
                engInputRef.current.style.backgroundColor="aquamarine"
                console.log(`Eng-OnFocus`)
            }}
            onBlur={()=>{
                console.log(`Eng-onBlur`)
                engInputRef.current.style.backgroundColor=""
            }}
            onChange={()=>{

                 let marks=engInputRef.current.value
                engSpanRef.current.innerHTML=marks >=35? "Pass":"Fail"
                engInputRef.current.style.backgroundColor="pink"
                engSpanRef.current.style.backgroundColor=marks>=35 ? "green":"orange"
                engSpanRef.current.innerHTML=marks>=35 ? "😇 Pass":"😅 Fail"
                console.log(`Eng-onChange`)
            }}>
           
            </input>
            <span ref={engSpanRef}></span>
        </div>
        <div>
            <label>Telugu:</label>
            <input ref={telInputRef}
            onFocus={()=>{
                telInputRef.current.style.backgroundColor="aquamarine"
                console.log(`Tel-onFocus`);
            }}
            onChange={()=>{
                
               let marks=telInputRef.current.value
               
               telInputRef.current.style.backgroundColor="pink"
               telSpanRef.current.style.backgroundColor= marks>=35? "green":"orange"
               telSpanRef.current.innerHTML=marks>=35 ? "😇 Pass":"😅 Fail"
                console.log(`Tel-onChange`);
            }}
            onBlur={()=>{
                telInputRef.current.style.backgroundColor=""
                console.log(`Tel-onBlur`);
            }}>
                
            </input>
            <span ref={telSpanRef}></span>
        </div>
        <div>
            <label>Hindi:</label>
            <input ref={hinInputRef}
            onFocus={()=>{
                hinInputRef.current.style.backgroundColor="aquamarine"
                console.log(`Hin-onFocus`);
            }}
            onChange={()=>{
                hinInputRef.current.style.backgroundColor="pink"
             let marks=hinInputRef.current.value
                hinSpanRef.current.style.backgroundColor=marks>=35? "green":"orange"
                hinSpanRef.current.innerHTML=marks>=35? "😇 Pass":"😅 Fail"
                 console.log(`Hin-onChange`);
            }}
            onBlur={()=>{
                hinInputRef.current.style.backgroundColor=""
                console.log(`Hin-onBlur`);
            }}>
            
            </input>
            <span ref={hinSpanRef}></span>
        </div>
        <div>
            <label>Maths:</label>
            <input ref={matInputRef}
            onFocus={()=>{
                matInputRef.current.style.backgroundColor="aquamarine"
                console.log(`Mat-onFocus`);
            }}
            onChange={()=>{
                matInputRef.current.style.backgroundColor="pink"
                let marks=matInputRef.current.value
                matSpanRef.current.style.backgroundColor=marks>=35? "green":"orange"
                matSpanRef.current.innerHTML=marks>=35? "😇 Pass":"😅 Fail"
                console.log(`Mat-onChange`);
            }}
            onBlur={()=>{
                matInputRef.current.style.backgroundColor=""
                console.log(`Mat-onBlur`);
            }}>
                
            </input>
            <span ref={matSpanRef}></span>
        </div>
        <div>
            <label>Science:</label>
            <input ref={sciInputRef}
             onFocus={()=>{
                sciInputRef.current.style.backgroundColor="aquamarine"
                console.log(`Sci-onFocus`);
            }}
            onChange={()=>{
                let marks=sciInputRef.current.value
                sciSpanRef.current.style.backgroundColor=marks>=35? "green":"orange"
                sciSpanRef.current.innerHTML=marks>=35? "😇 Pass":"😅 Fail"
                sciInputRef.current.style.backgroundColor="pink"
                console.log(`Sci-onChange`);
            }}
            onBlur={()=>{
                sciInputRef.current.style.backgroundColor=""
                console.log(`Sci-onBlur`);
            }}></input>
            <span ref={sciSpanRef}></span>
        </div>
        <div>
            <label>Social:</label>
            <input ref={socInputRef}
             onFocus={()=>{
                socInputRef.current.style.backgroundColor="aquamarine"
                console.log(`Soc-onFocus`);
            }}
            onChange={()=>{
                socInputRef.current.style.backgroundColor="pink"
                let marks=socInputRef.current.value
                socSpanRef.current.style.backgroundColor=marks>=35? "green":"orange"
                socSpanRef.current.innerHTML=marks>=35? "😇 Pass":"😅 Fail"
                
                console.log(`Soc-onChange`);
            }}
            onBlur={()=>{
                socInputRef.current.style.backgroundColor=""
                console.log(`Soc-onBlur`);
            }}>
                
            </input>
            <span ref={socSpanRef}></span>
        </div>
        <div>
            <button type="button" onClick={()=>{
                let firstName=firstNameInputRef.current.value;
                let lastName=lastNameInputRef.current.value;
                let engMarks=Number(engInputRef.current.value);
                let telMarks=Number(telInputRef.current.value);
                let hinMarks=Number(hinInputRef.current.value);
                let matMarks=Number(matInputRef.current.value);
                let sciMarks=Number(sciInputRef.current.value);
                let socMarks=Number(socInputRef.current.value);

                let totalMarks=engMarks+telMarks+hinMarks+matMarks+sciMarks+socMarks;
            
                console.log(`Mr.${firstName} ${lastName} your total marks is ${totalMarks}`);
                resultLabelRef.current.innerHTML=`Mr.${firstName} ${lastName} your total marks is ${totalMarks}`

            }}>Calculate</button>
        </div>
        <div>
            <label ref={resultLabelRef} className="innerLabel">please enter your values</label>
        </div>
     </form>
      
    </div>
  )
}

export default MarkSheet
